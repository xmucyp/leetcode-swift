import Foundation

//Valid Parentheses
func isValid(_ s: String) -> Bool {
    
    let map:[Character:Character] = ["}":"{", "]":"[", ")":"("]
    var stack = [Character]()
    
    for ch in s {
        if let _ = map[ch] {
            if stack.popLast() != map[ch] {
                return false
            }
        } else {
            stack.append(ch)
        }
    }
    
    if !stack.isEmpty {
        return false
    }

    return true
}

//isValid("{")
