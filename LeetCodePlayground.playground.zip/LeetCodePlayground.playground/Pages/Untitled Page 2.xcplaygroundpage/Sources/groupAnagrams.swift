import Foundation

func groupAnagrams(_ strs: [String]) -> [[String]] {
    var map = [String: [String]]()

    for s in strs {
        let key = String(s.sorted())
        if map[key] == nil {
            map[key] = [String]()
        }
        map[key]?.append(s)
    }
    var arrs = [[String]]()
    for arr in map.values {
        arrs.append(arr)
    }

    return arrs
}
