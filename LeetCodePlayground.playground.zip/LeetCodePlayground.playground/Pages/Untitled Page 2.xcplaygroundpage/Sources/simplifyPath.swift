import Foundation

func simplifyPath(_ path: String) -> String {
    let pathArray = path.components(separatedBy: "/")
    var stack = [String]()
    for item in pathArray {
        if item == ".." {
            stack.popLast()
        } else if item != "" && item != "." {
            stack.append(item)
        }
    }
    
    return "/" + stack.joined(separator: "/")
}

//simplifyPath("/a//b/../c/")
