import UIKit

// func twoSum(_ nums:[Int], _ target:Int) ->[Int] {
//    var map = [Int: Int]()
//    for (i,v) in nums.enumerated() {
//        if let ind = map[target - v] {
//            return[i,ind]
//        }
//        map[v] = i
//    }
//    return [];
// }

//extension String {
//    var length: Int {
//        return count
//    }
//
//    subscript(i: Int) -> String {
//        return self[i ..< i + 1]
//    }
//
//    func substring(fromIndex: Int) -> String {
//        return self[min(fromIndex, length) ..< length]
//    }
//
//    func substring(toIndex: Int) -> String {
//        return self[0 ..< max(0, toIndex)]
//    }
//
//    subscript(r: Range<Int>) -> String {
//        let range = Range(uncheckedBounds: (lower: max(0, min(length, r.lowerBound)),
//                                            upper: min(length, max(0, r.upperBound))))
//        let start = index(startIndex, offsetBy: range.lowerBound)
//        let end = index(start, offsetBy: range.upperBound - range.lowerBound)
//        return String(self[start ..< end])
//    }
//}
//
//class Solution {
//    func longestCommonPrefix(_ strs: [String]) -> String {
//        if strs.count <= 0 {
//            return ""
//        }
//        var ans: String
//        ans = strs[0]
//        let ansLen = ans.length
//        for i in 0 ..< ansLen {
//            for j in 1 ..< strs.count {
//                let str = strs[j]
//                if i == strs[j].length || ans[i] != str[i] {
//                    return ans[0 ..< i]
//                }
//            }
//        }
//
//        return ans
//    }
//}
//
//let s = Solution()
//s.longestCommonPrefix(["aa", "a"])
